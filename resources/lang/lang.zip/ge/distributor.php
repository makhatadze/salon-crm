<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'title' => 'სადისტრიბუციო კომპანიები',
    'add' => 'დამატება',
    'number' => 'ნომერი',
    'purchasenumber' => 'ნასყიდობის ნომერი',
    'dept' => 'დავალიანება',
    'overheadnumber' => 'ზედნადების ნომერი',
    'dept' => 'დავალიანება',
    'checknumber' => 'გაგზავნამდე გადაამოწმეთ ნომერი',
    'person' => 'საკონტაქტო პირი',
    'text' => 'ტექსტი',
    'send' => 'გაგზავნა'
];